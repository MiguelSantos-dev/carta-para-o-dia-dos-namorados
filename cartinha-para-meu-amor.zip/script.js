function abrirCarta() {
  const carta = document.getElementById('carta');
  carta.classList.toggle('carta-aberta');
  document.getElementById('instrucao').style.display = 'none';
}
