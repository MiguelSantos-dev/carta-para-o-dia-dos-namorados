# 💌 Cartinha para Meu Amor

Uma pequena cartinha feita com carinho, usando HTML, CSS e JavaScript. Ao clicar na caixinha, a mensagem é revelada com amor. 🌸

## ✨ Como rodar

1. Clone o repositório:
```bash
git clone https://github.com/seu-usuario/cartinha-para-meu-amor.git
```

2. Abra o arquivo `index.html` no navegador.

## 💖 Deploy no GitHub Pages

Você pode subir isso no GitHub e ativar o GitHub Pages pelo menu de configurações. Depois é só enviar o link pra sua pessoa especial.

---
Feito com ❤️ por Miguel
